import React from "react";
import Button from "../Button/Button";
import classes from "./Card.module.css";

export default function Card(props) {
  return (
    <div className={classes.container}>
      <h1
        className={classes.heading}
        style={{ backgroundColor: `${props.color}` }}
      >
        {props.text}
      </h1>
      <div>
        <div className={classes.buttonContainer}>
          <Button text={"Sign Up - It's Free"} color={props.color} />
        </div>
        <section>
          {props.dummyArr.map((el, i) => {
            return (
              <div className={classes.element} key={i}>
                {el}
              </div>
            );
          })}
        </section>
        <div className={classes.foot}>{props.description}</div>
      </div>
    </div>
  );
}

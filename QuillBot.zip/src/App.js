import "./App.css";
import React from "react";
import Button from "./Button/Button";
import Introduction from "./Components/Introduction";
import Card from "./QuillBot Power/Card";

function App() {
  const freeDummyData = {
    dummyArr: [
      "125 words in the Paraphraser",
      "Standard and Fluency modes",
      "3 synonym options",
      "1 Freeze word or phrase",
      "1200 words in the Summarizer",
      "Faster processing speed",
      "Advanced grammar rewrites",
      "Compare Modes (Desktop only)",
      "Plagiarism Checker*",
      "Tone detection",
    ],
    text: "FREE",
    description: "No Credit Card Required",
    color: "green",
  };
  const premiumDummyData = {
    dummyArr: [
      "Unlimited words in the Paraphraser",
      "Standard, Fluency, Expand, Shorten, Formal, Simple, and Creative modes",
      "4 synonym options",
      "Unlimited Freeze words and phrases",
      "6000 words in the Summarizer",
      "Faster processing speed",
      "Advanced grammar rewrites",
      "Compare Modes (Desktop only)",
      "Plagiarism Checker*",
      "Tone detection",
    ],
    text: "PREMIUM",
    description: "3-Day Money-Back Guarantee",
    color: "#DAA520",
  };

  return (
    <div className="App">
      <div>
        <Introduction />
        <Button text={"Upgrade to QuillBot Premium"} color={"green"} />
      </div>
      <div>
        <h1>Experience the full power of QuillBot</h1>
        <Card
          dummyArr={freeDummyData.dummyArr}
          text={freeDummyData.text}
          description={freeDummyData.description}
          color={freeDummyData.color}
        />
        <Card
          dummyArr={premiumDummyData.dummyArr}
          text={premiumDummyData.text}
          description={premiumDummyData.description}
          color={premiumDummyData.color}
        />
      </div>
    </div>
  );
}

export default App;

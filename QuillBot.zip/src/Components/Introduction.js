import classes from "./Introduction.module.css";

const Introduction = (props) => {
  return (
    <div className={classes.heading}>
      <h1>Save time and write with confidence</h1>
    </div>
  );
};

export default Introduction;
